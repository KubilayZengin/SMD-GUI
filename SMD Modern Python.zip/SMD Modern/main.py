import sys
import serial.tools.list_ports

from PyQt5 import QtCore, QtGui, QtWidgets, QtMultimedia
from PyQt5.QtWidgets import QDesktopWidget, QMessageBox
from PyQt5.QtCore import QSettings
from PyQt5.QtGui import QMovie

# Import Main Window UI
from SMD import Ui_MainWindow
from splash_screen import Ui_SplashScreen

# Globals: Programın farklı kısımlarında kullanılacak global değişkenler
counter = 0  # Animasyon ilerlemesi için sayaç


# Ana pencere
class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        QtWidgets.QMainWindow.__init__(self)
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)

        self.setWindowFlag(QtCore.Qt.FramelessWindowHint)
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground)

        # self.ui.scan_button.setEnabled(False)  # Butonun ilk başta inaktif olma kısmı (sonradan yapılacak)
        # baud rate  ve port seçiminden sonra aktifleşecek

        # QMovie ile GIF'i yükleme
        self.movie = QMovie("images/gif.gif")  # GIF dosyasının yolu
        self.ui.gif_label.setMovie(self.movie)
        self.ui.scan_button.enterEvent = self.start_gif
        self.ui.scan_ports_button.clicked.connect(self.find_ports)

    def find_ports(self):
        # Kullanılabilir COM portlarını bul
        com_list = serial.tools.list_ports.comports()
        available_coms = []
        if len(com_list) == 0:
            available_coms.append("None")
        else:
            for element in com_list:
                available_coms.append(element.device)
        self.ui.ports_comboBox.addItems(available_coms)

    def start_gif(self, event):
        self.movie.start()


class SplashScreen(QtWidgets.QMainWindow):
    def __init__(self):
        QtWidgets.QMainWindow.__init__(self)
        self.ui = Ui_SplashScreen()
        self.ui.setupUi(self)

        # Başlık çubuğunu kaldır
        self.setWindowFlag(QtCore.Qt.FramelessWindowHint)
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground)

        # Qtimer
        self.timer = QtCore.QTimer()
        self.timer.timeout.connect(self.progress)
        self.timer.start(25)  # Timer'ı başlat

        self.center_to_screen()
        self.ui.background.setVisible(False)

        # Animasyonları başlat
        self.logo_animation()
        self.ui.triangle2_animation_triggered = False

        # Ses efekti
        self.sound_effect = QtMultimedia.QSoundEffect()
        self.sound_effect.setSource(QtCore.QUrl.fromLocalFile("files/sound.wav"))
        self.start_animation()

        # Logo animasyonunu oluştur

    def logo_animation(self):
        opacity_effect = QtWidgets.QGraphicsOpacityEffect(self.ui.triangle1)
        self.ui.triangle1.setGraphicsEffect(opacity_effect)

        self.logo_opacity_animation = QtCore.QPropertyAnimation(
            opacity_effect, b'opacity', duration=880, startValue=0, endValue=1)
        self.logo_opacity_animation.setEasingCurve(QtCore.QEasingCurve.InOutCubic)

        opacity_effect2 = QtWidgets.QGraphicsOpacityEffect(self.ui.triangle2)
        self.ui.triangle2.setGraphicsEffect(opacity_effect2)

        self.logo_opacity_animation2 = QtCore.QPropertyAnimation(
            opacity_effect2, b'opacity', duration=880, startValue=0, endValue=1)
        self.logo_opacity_animation2.setEasingCurve(QtCore.QEasingCurve.InOutCubic)

        opacity_effect3 = QtWidgets.QGraphicsOpacityEffect(self.ui.triangle3)
        self.ui.triangle3.setGraphicsEffect(opacity_effect3)

        self.logo_opacity_animation3 = QtCore.QPropertyAnimation(
            opacity_effect3, b'opacity', duration=880, startValue=0, endValue=1)
        self.logo_opacity_animation3.setEasingCurve(QtCore.QEasingCurve.InOutCubic)

        opacity_effect4 = QtWidgets.QGraphicsOpacityEffect(self.ui.background)
        self.ui.background.setGraphicsEffect(opacity_effect4)

        self.logo_opacity_animation4 = QtCore.QPropertyAnimation(
            opacity_effect4, b'opacity', duration=1500, startValue=0, endValue=1)
        self.logo_opacity_animation4.setEasingCurve(QtCore.QEasingCurve.InOutCubic)

        # Animasyonları başlat

    def start_animation(self):
        self.sound_effect.play()
        self.anim_group = QtCore.QSequentialAnimationGroup()
        self.anim_group.addAnimation(self.logo_opacity_animation)
        self.anim_group.addAnimation(self.logo_opacity_animation2)
        self.anim_group.addAnimation(self.logo_opacity_animation3)

        self.anim_group.finished.connect(self.animation_finished)  # Animasyon tamamlandığında
        self.anim_group.start()

    def animation_finished(self):
        self.ui.background.setVisible(True)  # Animasyon tamamlandığında background görünür yap

        self.ui.anim_group2 = QtCore.QSequentialAnimationGroup()
        self.ui.anim_group2.addAnimation(self.logo_opacity_animation4)
        self.ui.anim_group2.start()

    def center_to_screen(self):
        frame_geometry = self.frameGeometry()
        screen_center = QDesktopWidget().availableGeometry().center()
        frame_geometry.moveCenter(screen_center)
        self.move(frame_geometry.topLeft())  # Pencereyi ekranda merkeze taşı

    def progress(self):
        global counter
        # print(counter)
        if counter >= 100:  # İlerleme 100'e ulaştığında
            self.timer.stop()  # Zamanlayıcıyı durdur
            self.main = MainWindow()  # Ana pencereyi oluştur
            self.main.show()  # Ana pencereyi göster
            self.close()  # Splash penceresini kapat
        counter += 0.5  # Sayaç değerini artır (arttırılabilir ya da azaltılabilir)


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    window = SplashScreen()
    window.show()
    sys.exit(app.exec_())  # Uygulamayı başlat
